package org.jsystem.quickstart;

import systemobject.terminal.Prompt;

import com.aqua.sysobj.conn.CliCommand;
import com.aqua.sysobj.conn.CliConnectionImpl;
import com.aqua.sysobj.conn.LinuxDefaultCliConnection;

import jsystem.framework.system.SystemObjectImpl;

public class MyTestEnvironment extends SystemObjectImpl {
    private String environmentName;
    private int switchNumber;
    private String switchList;
    private String tftpServer;
    private String imagePash;
	private String host;
    private String userName;
    private String password;
    private String promptString;
    private String stationPrompt;
    private CliConnectionImpl connection;
	
	public void init() throws Exception {
        super.init();
        report.report("In init method");
        connection = new LinuxDefaultCliConnection(getHost(),getUserName(),getPassword());
        Prompt p = new Prompt(stationPrompt,false);
        p.setCommandEnd(true);
        connection.addPrompts(new Prompt[]{p});
        connection.init();
    }

     public void close(){
         super.close();
         report.report("In close method");
     }
     
 	public void rawCommand(String rawCommand, String prompt) 
	        throws Exception {
		    CliCommand command = 
		        new CliCommand(rawCommand);
		    command.setPromptString(prompt);
	        connection.handleCliCommand(rawCommand, command);
	        setTestAgainstObject(command.getResult());
	}
	
	public void rawCommandNoTimeOut(String rawCommand, String prompt) 
	        throws Exception {
		    CliCommand command = 
		        new CliCommand(rawCommand);
		    command.setPromptString(prompt);
		    command.setTimeout(2*3600*1000);
	        connection.handleCliCommand(rawCommand, command);
	        setTestAgainstObject(command.getResult());
	}
	
     public String getEnvironmentName() {
         return environmentName;
     }

     public void setEnvironmentName(String environmentName) {
         this.environmentName = environmentName;
     }
     
     public int getSwitchNumber() {
         return switchNumber;
     }

     public void setSwitchNumber(int switchNumber) {
         this.switchNumber = switchNumber;
     }
     
     public String getSwitchList() {
         return switchList;
     }

     public void setSwitchList(String switchList) {
         this.switchList = switchList;
     }
     
     public String getTftpServer() {
         return tftpServer;
     }

     public void setTftpServer(String tftpServer) {
         this.tftpServer = tftpServer;
     }
     
     public String getImagePash() {
         return imagePash;
     }

     public void setImagePash(String imagePash) {
         this.imagePash = imagePash;
     }
     
 	public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getPromptString() {
        return promptString;
    }

    public void setPromptString(String promptString) {
        this.promptString = promptString;
    }
    
    public String getStationPrompt() {
        return stationPrompt;
    }

    public void setStationPrompt(String stationPrompt) {
        this.stationPrompt = stationPrompt;
    }
}
