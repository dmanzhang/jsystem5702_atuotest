package org.jsystem.quickstart;

import jsystem.framework.system.SystemObjectImpl;

import com.thoughtworks.selenium.Selenium;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverBackedSelenium;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.regex.Pattern;

public class GuioWeb extends SystemObjectImpl {
	private Selenium selenium;

	@Before
	public void setUp() throws Exception {
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://9.111.71.133/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	@Test
	public void test12212() throws Exception {
		selenium.open("/");
		selenium.type("id=username", "admin");
		selenium.type("id=password", "admin");
		selenium.click("css=input[type=\"submit\"]");
		selenium.waitForPageToLoad("30000");
		assertEquals("System dump exists in FLASH!", selenium.getAlert());
		selenium.selectFrame("NavTreeFrame");
		selenium.click("link=IBM Networking OS RackSwitch G8264");
		selenium.waitForPageToLoad("30000");
		selenium.click("link=Layer 3");
		selenium.waitForPageToLoad("30000");
		selenium.click("link=OSPFv3 Routing Protocol");
		selenium.waitForPageToLoad("30000");
		selenium.click("link=OSPFv3 Interfaces");
		selenium.waitForPageToLoad("30000");
	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
